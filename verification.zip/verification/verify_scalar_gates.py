"""Rebuild the exact scalar bootstrap and both necessary 1D gap gates.

This is a standard-library-only calculation. It neither loads historical
proof receipts nor evaluates the full twelve-dimensional objective. A
cooperative stop retains all unexamined cells and emits verified=false.
"""

import argparse
import hashlib
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True

from p6verify.exact import require
from p6verify.scalar_gates import calculate
from verify_local_rows import one_cpu

BASE = Path(__file__).resolve().parent


def source_hashes():
    paths = [Path(__file__),BASE/'verify_local_rows.py']
    paths += [BASE/'p6verify'/name for name in
              ('__init__.py','exact.py','six_mode_exact.py','scalar_gates.py','rows.py')]
    return {path.relative_to(BASE).as_posix():hashlib.sha256(path.read_bytes()).hexdigest()
            for path in paths}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--seconds',type=int,default=25)
    parser.add_argument('--evaluations',type=int,default=2500)
    parser.add_argument('--receipt',required=True,help='New JSON basename in receipts/')
    args = parser.parse_args()
    require(1 <= args.seconds <= 120 and 1 <= args.evaluations <= 2500,'Reviewed finite resource envelope')
    destination = (BASE/'receipts'/args.receipt).resolve()
    require(destination.parent == BASE/'receipts' and destination.suffix == '.json'
            and not destination.exists(),'New package-local scalar receipt')
    sources = source_hashes()
    resources = one_cpu()
    result = calculate(args.seconds,args.evaluations)
    require(source_hashes() == sources,'Scalar proof sources unchanged during execution')
    result.update(optimization=sys.flags.optimize,source_hashes=sources,resources=resources,
                  python_version=sys.version)
    with destination.open('x',encoding='utf-8') as stream:
        json.dump(result,stream,indent=2,sort_keys=True)
        stream.write('\n')
    summary = {key:value for key,value in result.items() if key != 'partitions'}
    summary['partitions'] = [{key:value for key,value in row.items() if key != 'leaves'}
                             for row in result['partitions']]
    print(json.dumps(summary,indent=2,sort_keys=True))
    return 0 if result['verified'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
