"""Regenerate complete scalar q/q'' tables; no multidimensional cover.

The first462 q bounds are deliberately zero and curvature unavailable.
All15393 entries are produced before a complete table is written.
"""
from fractions import Fraction as Q
import argparse
import hashlib
import json
import math
from pathlib import Path
import sys
import time
from p6verify.exact import require
from verify_local_rows import one_cpu

BASE = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--seconds',type=int,default=30)
    parser.add_argument('--output',default='six_mode_tables.json')
    args = parser.parse_args()
    require(1 <= args.seconds <= 30,'Cooperative scalar-table budget')
    destination = (BASE/'data'/args.output).resolve()
    require(destination.parent == BASE/'data' and destination.suffix == '.json'
            and not destination.exists(),'New local table file')
    one_cpu()
    from p6verify import kernel,profiles
    coefficients = tuple((j,Q(n,4000)) for j,n in enumerate((37,-69,-1,8,-11,2),1))
    kernel.configure_arb(128)
    constants = kernel.kernel_constants()
    grid,count,start_index = 500,15393,462
    q,second = [0.0]*start_index,[-math.inf]*start_index
    started = time.monotonic()
    for index in range(start_index,count):
        require(time.monotonic()-started < args.seconds,'INCOMPLETE: cooperative table budget exhausted')
        cell = kernel.closed_cell(index,grid)
        value = profiles.normalized_kernel(cell,coefficients,constants)
        absolute = kernel._arb_nonnegative_lower_to_float(value.abs_lower())
        lower = kernel.down_mul(absolute,absolute)
        _,_,derivative = profiles.squared_kernel_derivatives(cell,coefficients,constants)
        derivative_lower = kernel.arb_lower_to_float(derivative)
        require(math.isfinite(lower) and lower >= 0 and math.isfinite(derivative_lower),'Finite cell bounds')
        q.append(lower)
        second.append(derivative_lower)
    qhash,dhash = kernel.table_sha256(q),kernel.table_sha256(second)
    require(qhash == '720514e4c09259c32629bba740b5f7e3d61a3e85f6389ad7ae27bc61c0bb305c'
            and dhash == 'a67323d95f9407b91acf10bb517c60d8f4b2bb9cb73da8e4afc2523630ea0cb2',
            'Exact published scalar-table bytes rebuilt')
    sources = [Path(__file__),BASE/'verify_local_rows.py',*(BASE/'p6verify'/name for name in
               ('__init__.py','exact.py','rows.py','kernel.py','rounding.py','profiles.py'))]
    result = dict(schema='p6.six-mode-tables.v1',status='PASS_COMPLETE_SCALAR_TABLES',
        grid=grid,cell_count=count,start_index=start_index,precision_bits=128,
        profile=[[j,str(u)] for j,u in coefficients],q_binary64_sha256=qhash,
        q_second_binary64_sha256=dhash,q_lower_hex=[x.hex() for x in q],
        q_second_lower_hex=[x.hex() for x in second],optimization=sys.flags.optimize,
        elapsed_seconds=time.monotonic()-started,
        source_sha256={path.relative_to(BASE).as_posix():hashlib.sha256(path.read_bytes()).hexdigest() for path in sources},
        scope='Complete scalar cell tables only; no thirteen-point orthant cover is claimed.')
    with destination.open('x',encoding='utf-8') as stream:
        json.dump(result,stream,indent=2,sort_keys=True)
        stream.write('\n')
    print(json.dumps({k:v for k,v in result.items() if not k.endswith('_hex')},indent=2))


if __name__ == '__main__':
    main()
