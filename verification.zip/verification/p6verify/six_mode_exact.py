"""Exact six-mode point kernel, preserving the reviewed rational algorithm.

The old historical imports and example calculation are removed. Only local
standard-library interval primitives are used. No pressure cover runs here.
"""
from fractions import Fraction as Q
from math import factorial
from .exact import I,outer,require,rounded,sqrt_interval

U = [Q(n,4000) for n in (37,-69,-1,8,-11,2)]


def atan_inverse(n):
    partial = sum((Q((-1)**j,(2*j+1)*n**(2*j+1)) for j in range(41)),Q(0))
    return I(partial-Q(1,83*n**83),partial)


PI = rounded(16*atan_inverse(5)-4*atan_inverse(239))


def window_data():
    def series(offset):
        partial = sum((Q((-1)**j,2**j*factorial(2*j+offset)) for j in range(31)),Q(0))
        return I(partial-Q(1,2**31*factorial(62+offset)),partial)
    C,S = series(0),series(1)
    require(S.lo > 0,'Positive sinc denominator')
    R = Q(1,2)+C/S
    A = 1/(2*S*S)+C/(2*S)
    return R,A,R-A


R0 = rounded(window_data()[0])


def sincos_pi(q):
    integer = (q+Q(1,2))//1
    remainder = q-integer
    require(abs(remainder) <= Q(1,2),'Reduced angle domain')
    x = rounded(PI*remainder)
    require(-2 < x.lo <= x.hi < 2,'Taylor remainder domain')
    x2 = rounded(x*x)
    sine,cosine,st,ct = x,I(1),x,I(1)
    for j in range(1,24):
        st = rounded(-st*x2/Q(2*j*(2*j+1)))
        ct = rounded(-ct*x2/Q((2*j-1)*(2*j)))
        sine,cosine = rounded(sine+st),rounded(cosine+ct)
    se,ce = Q(2**49,factorial(49)),Q(2**48,factorial(48))
    sine,cosine = rounded(sine+I(-se,se)),rounded(cosine+I(-ce,ce))
    return (-sine,-cosine) if integer%2 else (sine,cosine)


def kernel(q):
    require(q >= 1,'Original exact point domain x>=1')
    sine,cosine = sincos_pi(q)
    t = rounded(PI*q)
    result = rounded((cosine-2*(R0-Q(1,2))*t*sine)/(1-2*t*t))
    for j,u in enumerate(U,1):
        basis = I(Q(1,2)) if q == j else rounded((-1)**j*q*sine/(PI*(q*q-j*j)))
        result = rounded(result+u*basis)
    return result


def kernel_extended(q):
    if q >= 1:
        return kernel(q)
    require(Q(9,10) <= q < 1,'Separately proved below-one domain')
    sine,cosine = sincos_pi(q)
    t = rounded(PI*q)
    denominator = 1-2*t*t
    require(denominator.hi < 0,'Strictly negative cosine denominator')
    result = rounded((cosine-2*(R0-Q(1,2))*t*sine)/denominator)
    for j,u in enumerate(U,1):
        require(q*q != j*j,'No below-one shifted-sinc resonance')
        result = rounded(result+u*rounded((-1)**j*q*sine/(PI*(q*q-j*j))))
    return result
