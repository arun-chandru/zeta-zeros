# Source provenance and publication changes

The files `p6verify/kernel.py`, `rounding.py`, and `report.py` are unchanged
copies from Ainta's MIT-licensed repository commit
`040c5e899e658aed7b56a2a87f501798fe10761d`. Their original SHA-256 values are:

| File | Original SHA-256 |
| --- | --- |
| kernel.py | E83AA966699770BC72F67D3E55079CFF89C2432A05AD25ABD12AFC8CBF9AF1DD |
| rounding.py | 2419F77BAE2FB73CCB1DA4E5D2BBAF3247E7D900D53871DE9011296F7DE5844E |
| report.py | 6305C3A072A3839AFF80AD9854FC8E1E259DF86078B8A20821FA778B966833FC |

Retain `LICENSE-THIRD-PARTY` with these files and their adaptations.

`cover.py` adapts the reviewed Ainta-derived local engine whose prepublication
SHA-256 was `B936C82A659CE80510D0B2877601498F64A1696E8D031E9A6D2CAC6ED1175879`.
The publication changes remove historical paths and file pins, select the
three kernel callbacks through an explicit argument, and remove the old
command-line wrapper. The mathematical acceptance algorithm is unchanged.
It retains outward cell bounds, complete sum-cell indices, signed Hessian
rounding, Arb LDL, affine/quadratic/signed-Taylor tests, reversal symmetry,
and exact-lattice derivative caching. Attribution is not a claim that the
modified engine or new row belongs to the original author.

The copied cosine kernel docstring describes the original verifier's
derivative domain `x>=.95`. The neutral v4 engine starts at grid index1001
for both rows. Its cells have `x>=.25025>1/4>1/(sqrt(2)*pi)`, so the same
rational derivative formula is valid and its denominators avoid zero.
This clarification does not edit the byte-preserved upstream file. The
original and neutral cosine curvature tables consequently have different
prefix conventions and must not be assigned the same digest by assumption.

`profiles.py` adapts the reviewed perturbed-kernel module whose prepublication
SHA-256 was `D6824731A4565F0B75F71A1D89D03449A2B87AC4A449979584FA0407D24BA6F5`.
The publication changes replace historical imports and the mutable global
profile with local imports and an immutable explicit parameter. The entire
shifted-sinc formula and derivative remainder bounds are unchanged.

The exact interval and scalar programs were written as standalone modules
for this package. They import no historical checker or saved enclosure.
The configurations and wrappers are also standalone publication sources.
Original hashes above are provenance, not runtime dependencies: no file
outside this directory is needed except the documented Python/Flint runtime.

No historical PASS receipt has been relabelled as a run of this package.
New receipts must be produced by actual executions and carry the new source
hashes. A finite cover or transcript is not externally peer-reviewed merely
because it received an internal code audit.

## Supplementary local certificates

`six_mode_exact.py` preserves the exact point algorithm of source
`40238A48972DE5FD2C34C2C6455114073B00A6C7EC85B61EEE6F03073C318114`,
whose elementary interval backend had source hash
`E34F6A966B1C8E80251E37701BDB5326BB6AE368E80160902F406BE159182CFC`.
The old example computations and private imports are removed. The original
41-term Machin intervals and31-term cosine constant, reduced trigonometric
Taylor intervals, and50-decimal rounding are preserved. The below-one
extension keeps its separate domain and denominator guards.

`supplement.py` combines the fixed-point/range-minimum primitives of source
`AE4ADC61D968048C33F0B0495A883CD9D9E728D9A8F42C8A0984AE24228F49E2`
with the exact LL cover of source
`612AA5169A7B697B346BBF9B62A60BC714535A0F0B9ADF1B78A1214DF5A36C46`.
It replaces inherited baseline and pair receipts by actual local recomputation
of their scalar guards and the complete8385-pair LL check. The shared table
loader validates both full numerical array digests, configuration, and
availability conventions; it imports no incomplete multidimensional pilot.

`triple_cover.py` adapts final source
`88A5486AC1BEB0BC669B0955AC00DE684DED733697A030CA4DE9404A461E84D3`.
Its three final targets, box subdivision, interval and LL replacement rules,
atomic Taylor/LDL algorithm, budget rollback and complete volume/tree
accounting are preserved. The fourth, endpoint configuration is the earlier
completed endpoint core/target from source `AE4ADC61...` above. Its correct
endpoint pressure is explicitly selected if an atomic Taylor test is ever
needed. Reflected SLL cases use only proved reversal, not permutation symmetry.

`build_supplement_tables.py` is the scalar-only extraction of the reviewed
table-construction loop formerly embedded in an incomplete13-point pilot.
It uses the same six-mode callback formulas and fixes grid500, precision128,
15393 entries, zero q prefix and unavailable curvature prefix through461.
All useful entries are rebuilt and both complete array digests must match.
The new table file is a scalar certificate, not a successful13D cover.
The known q/q'' array hashes are numerical inputs with a supplied generator;
they are not hashes of private sources that must be fetched to run this code.
