"""Arb enclosures for explicitly supplied finite Fourier profiles.

The Fourier transform is k0 plus the corresponding shifted-sinc pairs.
All point values and acceptance bounds use Arb; binary64 tables are widened
outwards. Taylor remainders follow by differentiating sinc(z)=int_0^1 cos(tz)dt,
and Taylor's theorem for real sine/cosine, not by an alternating-series test
on an interval. This module does not itself prove a pressure inequality.
Publication adaptation by R. Arun Chandru: immutable profile parameter
replaces the historical module-global selection; formulas are unchanged.
Derived from Ainta's MIT-licensed kernel; see ../LICENSE-THIRD-PARTY.
"""
from fractions import Fraction
from dataclasses import dataclass
import math
from flint import arb, fmpq
from . import kernel as original
from .rounding import down_mul

def sinc_derivatives(z):
    if z.abs_upper()<1:
        # Each power is evaluated on the entire real ball. The tail estimates
        # hold for every real member of that ball, including zero.
        K=8
        value=arb(0)
        first=arb(0)
        second=arb(0)
        square=z*z
        for n in range(K,-1,-1):
            sign=(-1)**n
            value=value*square+fmpq(sign,math.factorial(2*n+1))
            first=first*square-fmpq(sign,math.factorial(2*n+1)*(2*n+3))
            second=second*square-fmpq(sign,math.factorial(2*n)*(2*n+3))
        first*=z
        bound=z.abs_upper()
        e0=bound**(2*K+2)/math.factorial(2*K+3)
        e1=bound**(2*K+3)/(math.factorial(2*K+3)*(2*K+5))
        e2=bound**(2*K+2)/(math.factorial(2*K+2)*(2*K+5))
        return (value+arb(0,e0.abs_upper()),first+arb(0,e1.abs_upper()),
                second+arb(0,e2.abs_upper()))
    if not z.abs_lower()>0:
        raise RuntimeError('wide ball contains a removable pole; subdivide it')
    sine=z.sin()
    cosine=z.cos()
    square=z*z
    return (z.sinc(),(z*cosine-sine)/square,
            ((2-square)*sine-2*z*cosine)/(square*z))

def normalized_kernel(x,profile,constants=None):
    c=constants or original.kernel_constants()
    value=original.normalized_kernel(x,c)
    for j,u in profile:
        value+=arb(fmpq(u.numerator,u.denominator))*((c.pi*(x-j)).sinc()+
                   (c.pi*(x+j)).sinc())/2
    return value

def squared_kernel_derivatives(x,profile,constants=None):
    c=constants or original.kernel_constants()
    a=sinc_derivatives(c.pi*x-c.inv_sqrt_two)
    b=sinc_derivatives(c.pi*x+c.inv_sqrt_two)
    k=[(a[d]+b[d])*c.pi**d/(2*c.k_zero) for d in range(3)]
    for j,u in profile:
        a=sinc_derivatives(c.pi*(x-j))
        b=sinc_derivatives(c.pi*(x+j))
        coefficient=arb(fmpq(u.numerator,u.denominator))/2
        for d in range(3):
            k[d]+=coefficient*c.pi**d*(a[d]+b[d])
    return k[0]*k[0],2*k[0]*k[1],2*(k[1]*k[1]+k[0]*k[2])

def build_kernel_table(grid,cell_count,profile,precision=128):
    original.configure_arb(precision)
    c=original.kernel_constants()
    result=[]
    for i in range(cell_count):
        value=normalized_kernel(original.closed_cell(i,grid),profile,c)
        lower=original._arb_nonnegative_lower_to_float(value.abs_lower())
        result.append(down_mul(lower,lower))
    return result

def build_second_derivative_lower_table(grid,cell_count,start_index,profile,precision=128):
    original.configure_arb(precision)
    c=original.kernel_constants()
    result=[-math.inf]*cell_count
    for i in range(start_index,cell_count):
        _,_,second=squared_kernel_derivatives(original.closed_cell(i,grid),profile,c)
        result[i]=original.arb_lower_to_float(second)
    return result

def energy_cost(profile):
    return sum((arb(fmpq(u.numerator,u.denominator))**2*
                (arb(fmpq(1,2))-1/(4*arb.pi()**2*j*j)) for j,u in profile),arb(0))


@dataclass(frozen=True)
class Profile:
    coefficients: tuple

    def __post_init__(self):
        if not isinstance(self.coefficients, tuple) or not all(
                isinstance(pair, tuple) and len(pair) == 2
                and isinstance(pair[0], int) and pair[0] >= 1
                and isinstance(pair[1], Fraction) for pair in self.coefficients):
            raise ValueError('Immutable exact Fourier profile required')
        if len({j for j,u in self.coefficients}) != len(self.coefficients):
            raise ValueError('Repeated Fourier modes')

    def build_kernel_table(self,grid,cell_count,precision=128):
        return build_kernel_table(grid,cell_count,self.coefficients,precision)

    def build_second_derivative_lower_table(self,grid,cell_count,start_index,precision=128):
        return build_second_derivative_lower_table(grid,cell_count,start_index,
                                                   self.coefficients,precision)

    def squared_kernel_derivatives(self,x,constants=None):
        return squared_kernel_derivatives(x,self.coefficients,constants)
