"""Parameterized local-window certificate derived from Ainta commit040c5e8.
MIT-licensed upstream method: Arb cell bounds, sparse minima, convex tangents.
Version 4 adds reversal representatives and bounded exact-center memoization.
No floating discovery value is used as an acceptance decision.

Publication adaptation by R. Arun Chandru: local imports and explicit
immutable callback selection only; the acceptance algorithm is unchanged.
Copyright (c) 2026 ainta; see ../LICENSE-THIRD-PARTY.
"""

from __future__ import annotations

from fractions import Fraction
from functools import lru_cache

import itertools
import math
import time
from typing import Iterable, List, Optional, Sequence, Tuple

from flint import arb, fmpq

from . import kernel as cosine_kernel
from .kernel import (
    RangeMinimum,
    kernel_constants,
    table_sha256,
)
from .report import VerificationReport
from .rounding import down_add, down_mul, down_ratio, up_ratio


CellRange = Tuple[int, int]
WindowBox = Tuple[CellRange, ...]


def _components(indices: Iterable[int]) -> List[CellRange]:
    result: List[List[int]] = []
    for index in indices:
        if not result or index > result[-1][1] + 1:
            result.append([index, index])
        else:
            result[-1][1] = index
    return [(left, right) for left, right in result]


def verify_window(points: int, target: Fraction, pressure: Fraction, grid: int,
                  node_limit: int, progress_every: int = 10000, *,
                  callbacks=None) -> VerificationReport:
    """Prove the specified weighted local pressure on the entire orthant."""
    if not (3 <= points <= 20 and target > 0 and pressure > 0 and grid >= 100):
        raise ValueError("invalid certificate parameters")
    callbacks = cosine_kernel if callbacks is None else callbacks
    build_kernel_table = callbacks.build_kernel_table
    build_second_derivative_lower_table = callbacks.build_second_derivative_lower_table
    squared_kernel_derivatives = callbacks.squared_kernel_derivatives
    Q = points-1
    GRID = grid
    PRECISION_BITS = 128
    TARGET_NUMERATOR, TARGET_DENOMINATOR = target.numerator, target.denominator
    P_NUMERATOR, PRESSURE_DENOMINATOR = pressure.numerator, pressure.denominator
    cap = target*GRID/pressure
    PRESSURE_CUTOFF_CELLS = -(-cap.numerator//cap.denominator)
    if PRESSURE_CUTOFF_CELLS > 500000:
        raise RuntimeError("table budget exceeded")
    COEFFICIENTS = {j:down_ratio(2,points-j) for j in range(1,points)}
    COEFFICIENTS_UP = {j:up_ratio(2,points-j) for j in range(1,points)}
    COEFFICIENT_RATIONALS = {j:fmpq(2,points-j) for j in range(1,points)}

    started = time.perf_counter()
    cell_count = PRESSURE_CUTOFF_CELLS + Q + 2
    print(f"PHASE q_table_start cells={cell_count} elapsed={time.perf_counter()-started:.6f}",flush=True)
    table = build_kernel_table(GRID, cell_count, PRECISION_BITS)
    print(f"PHASE q_table_complete cells={len(table)} elapsed={time.perf_counter()-started:.6f}",flush=True)
    ranges = RangeMinimum(table)
    print(f"PHASE curvature_table_start first={GRID//4+1} elapsed={time.perf_counter()-started:.6f}",flush=True)
    second_table = build_second_derivative_lower_table(
        GRID, cell_count, start_index=GRID//4+1, precision=PRECISION_BITS
    )
    print(f"PHASE curvature_table_complete cells={len(second_table)} elapsed={time.perf_counter()-started:.6f}",flush=True)
    second_ranges = RangeMinimum(second_table)
    constants = kernel_constants()
    target_upper = up_ratio(TARGET_NUMERATOR, TARGET_DENOMINATOR)

    def kernel_min(left: int, right: int) -> float:
        # If the interval extends past the pressure cutoff, zero is still a
        # rigorous lower bound for the nonnegative function w=k^2.
        if right >= ranges.length:
            return 0.0
        return ranges.query(left, right)

    def second_derivative_min(left: int, right: int) -> float:
        if right >= second_ranges.length:
            return float("-inf")
        return second_ranges.query(left, right)

    # The nonnegative one-gap contribution p*g + (2/Q)*w(g) is part
    # of the objective. A cell where it suffices can be excluded.
    surviving_cells: List[int] = []
    for index in range(PRESSURE_CUTOFF_CELLS):
        one_body = down_ratio(P_NUMERATOR * index, GRID * PRESSURE_DENOMINATOR)
        one_body = down_add(one_body, down_mul(COEFFICIENTS[1], table[index]))
        if one_body < target_upper:
            surviving_cells.append(index)
    components = _components(surviving_cells)

    cover_initial_boxes = len(components) ** Q
    if cover_initial_boxes > 1000000:
        raise RuntimeError("initial box budget exceeded")
    stack: List[Tuple[WindowBox, int]] = [
        (tuple(parts), 0)  # type: ignore[arg-type]
        for parts in itertools.product(components, repeat=Q)
        if tuple(parts) <= tuple(reversed(parts))
    ]
    initial_boxes = len(stack)
    print(f"PHASE roots_ready components={len(components)} representatives={initial_boxes} elapsed={time.perf_counter()-started:.6f}",flush=True)
    nodes = pruned = splits = maximum_depth = 0
    pressure_pruned = interval_pruned = 0
    tangent_pruned = 0

    def box_lower(box: WindowBox) -> float:
        lows = [part[0] for part in box]
        highs = [part[1] for part in box]
        low_prefix = [0]
        high_prefix = [0]
        for low, high in zip(lows, highs):
            low_prefix.append(low_prefix[-1] + low)
            high_prefix.append(high_prefix[-1] + high)

        result = down_ratio(P_NUMERATOR * low_prefix[-1], GRID * PRESSURE_DENOMINATOR)
        for span in range(1, points):
            coefficient = COEFFICIENTS[span]
            for start in range(points - span):
                left = low_prefix[start + span] - low_prefix[start]
                # A sum of `span` closed cells has this inclusive cell range.
                right = (
                    high_prefix[start + span] - high_prefix[start] + span - 1
                )
                result = down_add(
                    result,
                    down_mul(coefficient, kernel_min(left, right)),
                )
        return result

    def coefficient_times_signed_lower(span: int, lower: float) -> float:
        if lower == float("-inf"):
            return lower
        coefficient = COEFFICIENTS[span] if lower >= 0.0 else COEFFICIENTS_UP[span]
        # Multiplication is rounded to nearest first, then widened down.
        return math.nextafter(coefficient * lower, -math.inf)

    def float_ldl_is_positive(matrix: List[List[float]]) -> bool:
        """Cheap heuristic; success is rechecked with Arb below."""

        lower = [[0.0] * Q for _ in range(Q)]
        diagonal = [0.0] * Q
        for column in range(Q):
            pivot = matrix[column][column]
            for previous in range(column):
                pivot -= (
                    lower[column][previous]
                    * lower[column][previous]
                    * diagonal[previous]
                )
            if pivot <= 1e-12:
                return False
            diagonal[column] = pivot
            lower[column][column] = 1.0
            for row in range(column + 1, Q):
                value = matrix[row][column]
                for previous in range(column):
                    value -= (
                        lower[row][previous]
                        * lower[column][previous]
                        * diagonal[previous]
                    )
                lower[row][column] = value / pivot
        return True

    def exact_float(value: float) -> arb:
        numerator, denominator = value.as_integer_ratio()
        return arb(fmpq(numerator, denominator))

    def arb_ldl_decomposition(terms: Sequence[Tuple[int, int, float]]):
        """Return proved positive LDL factors, or None; no float acceptance."""

        matrix = [[arb(0) for _ in range(Q)] for _ in range(Q)]
        for start, span, coefficient in terms:
            exact = exact_float(coefficient)
            for row in range(start, start + span):
                for column in range(start, start + span):
                    matrix[row][column] += exact

        lower = [[arb(0) for _ in range(Q)] for _ in range(Q)]
        diagonal = [arb(0) for _ in range(Q)]
        for column in range(Q):
            lower[column][column] = arb(1)
            pivot = matrix[column][column]
            for previous in range(column):
                pivot -= (
                    lower[column][previous]
                    * lower[column][previous]
                    * diagonal[previous]
                )
            if not (pivot > 0):
                return None
            diagonal[column] = pivot
            for row in range(column + 1, Q):
                value = matrix[row][column]
                for previous in range(column):
                    value -= (
                        lower[row][previous]
                        * lower[column][previous]
                        * diagonal[previous]
                    )
                lower[row][column] = value / pivot
        return lower, diagonal

    @lru_cache(maxsize=32768)
    def center_derivatives(index: int):
        # Every center sum lies on the exact 1/(2*GRID) lattice. Cached Arb
        # triples are read-only; only products/new expressions use them.
        return squared_kernel_derivatives(arb(fmpq(index,2*GRID)),constants)

    def convex_tangent_lower(box: WindowBox) -> Optional[arb]:
        """Return a rigorous center/gradient lower bound with Hessian remainder."""

        low_prefix = [0]
        high_prefix = [0]
        for low, high in box:
            low_prefix.append(low_prefix[-1] + low)
            high_prefix.append(high_prefix[-1] + high)

        terms: List[Tuple[int, int, float]] = []
        heuristic = [[0.0] * Q for _ in range(Q)]
        for span in range(1, points):
            for start in range(points - span):
                left = low_prefix[start + span] - low_prefix[start]
                right = (
                    high_prefix[start + span] - high_prefix[start] + span - 1
                )
                second_lower = second_derivative_min(left, right)
                scalar = coefficient_times_signed_lower(span, second_lower)
                if scalar == float("-inf"):
                    return None
                terms.append((start, span, scalar))
                for row in range(start, start + span):
                    for column in range(start, start + span):
                        heuristic[row][column] += scalar

        decomposition = arb_ldl_decomposition(terms) if float_ldl_is_positive(heuristic) else None
        convex = decomposition is not None
        # For a scalar L<0 and a span-vector v, L*v*v^T >= L*span*I.
        # Drop positive rank-one terms. Their sum gives a global Hessian
        # lower bound lambda*I on this box even when convexity is unavailable.
        curvature = arb(0)
        if not convex:
            for start, span, scalar in terms:
                if scalar < 0:
                    curvature += exact_float(scalar)*span

        midpoints = [fmpq(low + high + 1, 2 * GRID) for low, high in box]
        radii = [fmpq(high - low + 1, 2 * GRID) for low, high in box]
        value = sum((arb(point) for point in midpoints), arb(0)) * arb(fmpq(P_NUMERATOR, PRESSURE_DENOMINATOR))
        gradient = [arb(fmpq(P_NUMERATOR, PRESSURE_DENOMINATOR)) for _ in range(Q)]

        for span in range(1, points):
            coefficient = arb(COEFFICIENT_RATIONALS[span])
            for start in range(points - span):
                point = sum(midpoints[start : start + span], fmpq(0))
                index=int(point*(2*GRID))
                if fmpq(index,2*GRID) != point:
                    raise RuntimeError("center-lattice identity failed")
                potential, derivative, _ = center_derivatives(index)
                value += coefficient * potential
                for coordinate in range(start, start + span):
                    gradient[coordinate] += coefficient * derivative

        lower = value
        for derivative, radius in zip(gradient, radii):
            lower -= derivative.abs_upper() * arb(radius)
        if not convex:
            lower += curvature * sum((arb(radius)*arb(radius) for radius in radii), arb(0))/2
        else:
            # Taylor gives F(c+u) >= F(c)+g.u+u^T H_- u/2
            # throughout this box. Its unconstrained quadratic minimum is
            # F(c)-g^T H_-^{-1} g/2, hence a lower bound even if the
            # unconstrained minimizer lies outside the box. For H_-=LDL^T,
            # solve L*y=g and use g^T H_-^{-1}g=sum y_j^2/D_j.
            factor, diagonal = decomposition
            solved = []
            for row in range(Q):
                solved.append(gradient[row]-sum(
                    (factor[row][j]*solved[j] for j in range(row)), arb(0)))
            quadratic = value-sum(
                (solved[j]*solved[j]/diagonal[j] for j in range(Q)), arb(0))/2
            if quadratic > lower:
                lower = quadratic
        return lower

    while stack:
        box, depth = stack.pop()
        nodes += 1
        if nodes > node_limit:
            raise RuntimeError("node budget exhausted; no certificate established")
        maximum_depth = max(maximum_depth, depth)
        if progress_every and nodes % progress_every == 0:
            print(f"PROGRESS window{points} nodes={nodes} pending={len(stack)} depth={maximum_depth} elapsed={time.perf_counter()-started:.6f}",flush=True)

        if sum(part[0] for part in box) >= PRESSURE_CUTOFF_CELLS:
            pruned += 1
            pressure_pruned += 1
            continue

        lower = box_lower(box)
        if lower >= target_upper:
            pruned += 1
            interval_pruned += 1
            continue

        tangent_lower = convex_tangent_lower(box)
        if tangent_lower is not None and tangent_lower >= arb(
            fmpq(TARGET_NUMERATOR, TARGET_DENOMINATOR)
        ):
            pruned += 1
            tangent_pruned += 1
            continue

        widths = [right - left for left, right in box]
        if max(widths) == 0:
            raise RuntimeError(
                f"{points}-point certificate failed at a terminal cell: "
                f"box={box}, lower={lower.hex()}"
            )

        splits += 1
        coordinate = max(range(Q), key=widths.__getitem__)
        left, right = box[coordinate]
        midpoint = (left + right) // 2
        lower_half = list(box)
        upper_half = list(box)
        lower_half[coordinate] = (left, midpoint)
        upper_half[coordinate] = (midpoint + 1, right)
        stack.append((tuple(lower_half), depth + 1))  # type: ignore[arg-type]
        stack.append((tuple(upper_half), depth + 1))  # type: ignore[arg-type]

    elapsed = time.perf_counter() - started
    component_text = ";".join(f"[{a},{b}]" for a, b in components)
    return VerificationReport(
        certificate=f"{points}-point",
        verified=True,
        target=f"weighted V{points} + ({pressure}) span >= {target}",
        grid=GRID,
        precision_bits=PRECISION_BITS,
        kernel_table_sha256=table_sha256(table),
        nodes=nodes,
        pruned=pruned,
        splits=splits,
        maximum_depth=maximum_depth,
        initial_boxes=initial_boxes,
        elapsed_seconds=elapsed,
        details={
            "pressure_pruned": pressure_pruned,
            "cover_initial_boxes_before_reversal": cover_initial_boxes,
            "reversal_symmetry": "uniform distance weights, g -> reversed(g)",
            "center_cache_maxsize": 32768,
            "center_cache_hits": center_derivatives.cache_info().hits,
            "center_cache_misses": center_derivatives.cache_info().misses,
            "points": points,
            "epsilon": str(target),
            "pressure": str(pressure),
            "cutoff_cells": PRESSURE_CUTOFF_CELLS,
            "interval_pruned": interval_pruned,
            "tangent_pruned": tangent_pruned,
            "second_derivative_table_sha256": table_sha256(second_table),
            "surviving_gap_components_cells": component_text,
            "surviving_gap_components_count": len(components),
        },
    )
