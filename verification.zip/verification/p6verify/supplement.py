"""Shared exact primitives for the supplementary three-gap certificates.

The fixed-point/minimum rules are the reviewed historical rules, without
private-note or pilot imports. Baseline scalar guards and the complete LL
credit are recomputed before any triple uses them. Analytic derivative and
tail proofs are stated in the companion supplement.
"""
from fractions import Fraction as Q
import hashlib
import json
import math
from pathlib import Path
import struct
import time
from .exact import require
from . import six_mode_exact as point

BASE = Path(__file__).resolve().parent.parent
PE,PI = Q(811,4800000),Q(6359,24000000)
SHORT,LONG,KAPPA = Q(53,50),Q(203,100),Q(3,100000)
GRID,BITS,SCALE = 500,80,1<<80
PROFILE = [str(Q(n,4000)) for n in (37,-69,-1,8,-11,2)]
TABLE_PIN = '720514E4C09259C32629BBA740B5F7E3D61A3E85F6389AD7AE27BC61C0BB305C'
CURVATURE_PIN = 'A67323D95F9407B91ACF10BB517C60D8F4B2BB9CB73DA8E4AFC2523630EA0CB2'
PINS = {}
LAST_LL = None


class BudgetStop(Exception):
    pass


def checkpoint(deadline):
    if time.monotonic() >= deadline:
        raise BudgetStop()


def floor_scaled(value):
    return value.numerator*SCALE//value.denominator


def ceil_q(value):
    return -(-value.numerator//value.denominator)


def long_polynomial(d):
    return Q(1,93750)+(Q(1,3125)-PI)*d+Q(3,1250)*d*d


def short_polynomial(d,pressure):
    a = Q(19,10000)
    return a*a/6+(a/5-pressure)*d+Q(3,50)*d*d


def baseline_checks():
    require(point.U == [Q(u) for u in PROFILE] and sum(abs(u) for u in point.U) == Q(4,125),
            'Exact normalized six-mode perturbation')
    require(0 < PE < PI and 2*PE+10*PI == Q(239,80000),'Exact pressure vector')
    require(3 < point.PI.lo and point.PI.hi < Q(22,7) and point.PI.hi**2 < 10,'Pi guards')
    A = 2*(point.R0-Q(1,2))
    require(Q(3,2) < A.lo and A.hi < Q(24,11),'Cosine-density bounds')
    require((point.R0-Q(1,2)).lo > Q(3,4)
            and sum(abs(u) for u in point.U) <= Q(1,25),'Positive density lower bound')
    long_derivative = Q(15,82)-Q(137,11000)-Q(44,875)
    require(long_derivative > Q(3,25),'Long analytic derivative reserve')
    kl = point.kernel(LONG)
    require(kl.hi < -Q(1,125),'Long endpoint bound')
    density_lower,density_upper,right = Q(71,100),Q(311,275),Q(1063,1000)
    below = density_lower*Q(19,20)
    above = density_lower/right**2-5*density_upper*(right-1)**2
    require(min(below,above) > Q(3,5),'Short analytic derivative reserves')
    ks = point.kernel(SHORT)
    require(ks.lo > 5*PI and ks.lo > Q(19,10000),'Short endpoint and tail bound')
    return dict(status='PASS_BASELINE_SCALARS',long_derivative=str(long_derivative),
                long_kernel=point.outer(kl),short_kernel=point.outer(ks),
                short_derivative_below=str(below),short_derivative_above=str(above))


def table_data(deadline):
    checkpoint(deadline)
    path = BASE/'data'/'six_mode_tables.json'
    raw = path.read_bytes()
    data = json.loads(raw)
    require(data['schema'] == 'p6.six-mode-tables.v1'
            and data['status'] == 'PASS_COMPLETE_SCALAR_TABLES','Complete scalar table schema')
    require(data['grid'] == GRID and data['cell_count'] == 15393 and data['start_index'] == 462
            and data['precision_bits'] == 128
            and data['profile'] == [[j,u] for j,u in enumerate(PROFILE,1)],'Exact table identity')
    for key,pin in (('q_lower_hex',TABLE_PIN),('q_second_lower_hex',CURVATURE_PIN)):
        entries = data[key]
        require(len(entries) == 15393,'Complete scalar array')
        digest = hashlib.sha256()
        for i,entry in enumerate(entries):
            if i%256 == 0:
                checkpoint(deadline)
            x = float.fromhex(entry)
            if key == 'q_lower_hex':
                require(math.isfinite(x) and 0 <= x <= 1 and (i >= 462 or x == 0),'q entry')
            else:
                require(x == -math.inf if i < 462 else math.isfinite(x),'Curvature entry')
            digest.update(struct.pack('>d',x))
        require(digest.hexdigest().upper() == pin,'Exact certified array bytes')
    require(data['q_binary64_sha256'].upper() == TABLE_PIN
            and data['q_second_binary64_sha256'].upper() == CURVATURE_PIN,'Declared array hashes')
    PINS['data/six_mode_tables.json'] = hashlib.sha256(raw).hexdigest()
    for name in ('supplement.py','six_mode_exact.py','exact.py'):
        PINS['p6verify/'+name] = hashlib.sha256((BASE/'p6verify'/name).read_bytes()).hexdigest()
    return data


def certify_ll(exact,deadline):
    low,high = Q(39,20),Q(179033,81100)
    require(long_polynomial(LONG-low) == Q(3043,10**8) > KAPPA,'LL lower tail')
    require(high == LONG+KAPPA/PE and low > Q(5,3),'LL upper tail')
    left,right = 975,1103
    require(Q(left,GRID) <= low < high <= Q(right+1,GRID),'Closed LL core')
    def phi(x):
        return (PI if x <= LONG else PE)*(x-LONG)
    residual = {i:max(Q(0),exact[i]/6+phi(Q(i,GRID))) for i in range(left,right+1)}
    visited,minimum = 0,None
    for i in range(left,right+1):
        for j in range(i,right+1):
            checkpoint(deadline)
            lower = residual[i]+residual[j]+Q(2,11)*min(exact[i+j],exact[i+j+1])
            require(lower >= KAPPA,'LL cell credit not certified')
            minimum = lower if minimum is None else min(minimum,lower)
            visited += 1
    require(visited == 8385,'Complete LL swap-orbit inventory')
    return dict(status='PASS_LL_CREDIT',credit=str(KAPPA),visited=visited,minimum_exact_lower=str(minimum))


def load_table(deadline):
    global LAST_LL
    baseline_checks()
    data = table_data(deadline)
    exact = [Q.from_float(float.fromhex(value)) for value in data['q_lower_hex']]
    LAST_LL = certify_ll(exact,deadline)
    return [floor_scaled(value) for value in exact]


class RangeMinimum:
    def __init__(self,values,offset,deadline):
        require(len(values) > 0,'Nonempty minimum table')
        self.offset,self.length = offset,len(values)
        self.levels = [values]
        span = 1
        while 2*span <= self.length:
            checkpoint(deadline)
            old,row = self.levels[-1],[]
            for index in range(self.length-2*span+1):
                if index%256 == 0:
                    checkpoint(deadline)
                row.append(min(old[index],old[index+span]))
            self.levels.append(row)
            span *= 2

    def get(self,left,right):
        left,right = left-self.offset,right-self.offset
        require(0 <= left <= right < self.length,'Complete minimum range')
        level = (right-left+1).bit_length()-1
        width = 1<<level
        return min(self.levels[level][left],self.levels[level][right-width+1])


def residual_table(label,limits,table,deadline):
    left,right = limits
    result = []
    for index in range(left,right+1):
        if index%128 == 0:
            checkpoint(deadline)
        low = Q(index,GRID)
        if label == 'L':
            require(low >= Q(5,3),'Long whole-cell baseline domain')
            pressure_part = (PI if low <= LONG else PE)*(low-LONG)
        else:
            require(low >= Q(459,500),'Short whole-cell baseline domain')
            pressure_part = (PE if label == 'S_e' else PI)*(low-SHORT)
        result.append(max(0,table[index]//6+floor_scaled(pressure_part)))
    return RangeMinimum(result,left,deadline)


def volume(box):
    return math.prod(b-a+1 for a,b in box)


def encoded(box,depth):
    return dict(box=box,depth=depth)
