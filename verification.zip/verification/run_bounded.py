"""Hard-bounded supervisor for one publication seven-point cover.

The child sets one-CPU affinity and reduced priority before importing Arb.
This supervisor never manufactures a successful child receipt.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

from p6verify.exact import require
from p6verify.rows import ROWS

BASE = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--row',choices=tuple(ROWS),required=True)
    parser.add_argument('--nodes',type=int,required=True)
    parser.add_argument('--seconds',type=int,required=True)
    parser.add_argument('--receipt',required=True,help='New JSON basename in receipts/')
    args = parser.parse_args()
    require(1 <= args.nodes <= 2000000 and 1 <= args.seconds <= 600,'Bounded resources')
    receipt = (BASE/'receipts'/args.receipt).resolve()
    require(receipt.parent == BASE/'receipts' and receipt.suffix == '.json','Local JSON receipt')
    resource = receipt.with_name(receipt.stem+'_resource.json')
    log = receipt.with_name(receipt.stem+'.log')
    require(all(not path.exists() for path in (receipt,resource,log)),'All outputs must be new')
    child = BASE/'verify_local_rows.py'
    child_pin = hashlib.sha256(child.read_bytes()).hexdigest()
    command = [sys.executable,'-B','-u']+(['-OO'] if sys.flags.optimize == 2 else (['-O'] if sys.flags.optimize == 1 else []))
    command += [str(child),'--row',args.row,'--nodes',str(args.nodes),'--receipt',receipt.name]
    started = time.monotonic()
    timed_out = False
    environment = dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',
                       PYTHONUNBUFFERED='1')
    with log.open('x',encoding='utf-8') as output:
        process = subprocess.Popen(command,cwd=BASE,env=environment,stdin=subprocess.DEVNULL,
            stdout=output,stderr=subprocess.STDOUT,
            creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0)
        try:
            returncode = process.wait(timeout=args.seconds)
        except subprocess.TimeoutExpired:
            timed_out = True
            process.kill()
            returncode = process.wait()
    elapsed = time.monotonic()-started
    accepted = False
    receipt_pin = None
    if not timed_out and returncode == 0 and receipt.exists():
        raw = receipt.read_bytes()
        receipt_pin = hashlib.sha256(raw).hexdigest()
        data = json.loads(raw)
        require(data['schema'] == 'p6.local-row.v1' and data['status'] == 'PASS_COMPLETE_LOCAL_ROW'
                and data['row'] == ROWS[args.row].metadata()
                and data['optimization'] == sys.flags.optimize
                and data['source_sha256']['verify_local_rows.py'] == child_pin
                and data['report']['verified'] is True and data['resources']['enforced'] is True,
                'Successful child receipt binding')
        accepted = True
    result = dict(schema='p6.bounded-run.v1',status='PASS_COMPLETE_CHILD' if accepted else 'INCOMPLETE_OR_FAILED',
        row=args.row,optimization=sys.flags.optimize,wall_cap_seconds=args.seconds,node_cap=args.nodes,
        elapsed_seconds=elapsed,timed_out=timed_out,child_returncode=returncode,
        child_certificate_accepted=accepted,child_receipt_sha256=receipt_pin,
        child_source_sha256=child_pin,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        log_sha256=hashlib.sha256(log.read_bytes()).hexdigest(),
        scope='A hard runtime wrapper, not an independent mathematical cover checker.')
    with resource.open('x',encoding='utf-8') as output:
        json.dump(result,output,indent=2,sort_keys=True)
        output.write('\n')
    print(json.dumps(result,indent=2,sort_keys=True),flush=True)
    return 0 if accepted else 1


if __name__ == '__main__':
    raise SystemExit(main())
