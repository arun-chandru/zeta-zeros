# Standalone verification package

This publication implementation contains the two adopted seven-point local
rows, an independent exact scalar checker, and the separate thirteen-point
local-region supplement. It is not the historical research archive. No
historical absolute paths, repository checkout, saved decimal enclosures,
or private proof-note imports are needed. Source availability alone is not
a claim that a particular new execution has completed: inspect its receipt.

## Requirements

Python 3.10 or later. `verify_counts.py` needs only the standard library.
The local-row cover needs `python-flint==0.9.0`; install the declared
dependency in your own environment, for example with
`python -m pip install -r requirements.txt`. No runtime is bundled.
The Linux and Windows cover wrappers enforce one CPU and reduced priority;
other platforms fail closed until an affinity implementation is supplied.

## Exact scalar check

From this directory:

    python -B verify_counts.py --receipt counts_O0_replay.json
    python -B -OO verify_counts.py --receipt counts_OO_replay.json

These commands recompute pi, the two profile energies and dilation constants,
all five headline expressions, threshold and multiplicity guards, and fixed
cutoff-family formulas. They do not prove a local row or the analytic
zero-count transfer. Their reported scope is explicitly conditional on
those separate theorems. Headline margins are exact rational enclosures.

## Complete local rows

The exact row identifiers are `cosine` and `two_mode`. Both use seven points,
all 21 unordered pair terms with coefficients `2/(7-h)`, grid 4000, and
128-bit Arb arithmetic. The cosine row is `(epsilon,p)=(19/5000,1/3000)`;
the two-mode row is `(7/400,1/500)` with coefficients `(13/500,-7/500)`.
All three callback families use the same explicitly selected kernel.

Example bounded replay commands, requiring the stated resources:

    python -B run_bounded.py --row two_mode --seconds 300 --nodes 300000 --receipt two_mode_O0_replay.json
    python -B -OO run_bounded.py --row two_mode --seconds 300 --nodes 300000 --receipt two_mode_OO_replay.json
    python -B run_bounded.py --row cosine --seconds 600 --nodes 1000000 --receipt cosine_O0_replay.json
    python -B -OO run_bounded.py --row cosine --seconds 600 --nodes 1000000 --receipt cosine_OO_replay.json

These are finite budgets, not completion predictions. No run is launched by
importing a module or reading this file. A timeout, node exhaustion, unresolved
atomic cell, import failure, or exception yields no accepted complete proof.
The supervisor writes a separate resource record and log. It is a hard
wall-clock wrapper; the proof engine by itself has only a node budget.
Use new output basenames for every run. Existing files are never overwritten.

The engine rebuilds complete q and q'' tables from the kernel rather than
trusting a saved digest. Non-finite curvature disables derivative acceptance;
q outside the table has safe lower bound zero. The closed-cell sum endpoint
is `sum(upper_indices)+number_of_gaps-1`. Signed curvature coefficients are
rounded in the appropriate direction. A floating LDL screen only selects a
possible test; Arb must separately prove all positive pivots. Every accepted
leaf has a rigorous whole-box bound. Reversal is valid for these uniform
distance weights and equal-coordinate pressures. Stack exhaustion proves
coverage; tree counts and hashes are additional consistency checks only.

The unchanged upstream kernel docstring describes its original derivative
use above `.95`. Here both rows start curvature at index1001, or `.25025`,
which is also valid: every queried cell is strictly above
`1/4 > 1/(sqrt(2)*pi)`, so both cosine shifted arguments exclude zero.
The original cosine table used a different curvature prefix; its old hash
must not be assumed for this new complete table.

## Supplementary local-region replay

The six-mode density is different from both main densities. Its fixed
coefficients are `(37,-69,-1,8,-11,2)/4000`. First generate the complete
scalar tables (Arb required), and reconstruct the necessary scalar gates
(standard library only):

    python -B build_supplement_tables.py --seconds 30 --output six_mode_tables_replay.json
    python -B verify_scalar_gates.py --seconds 60 --evaluations 2500 --receipt scalar_gates_O0_replay.json
    python -B -OO verify_scalar_gates.py --seconds 60 --evaluations 2500 --receipt scalar_gates_OO_replay.json

The table is written only after all15393 entries and both exact binary64
array hashes agree. It imports no old multidimensional pilot. For a fresh
table replay use another `--output` basename and compare all entries. The
triple loader uses `data/six_mode_tables.json`, which is the generated
canonical data file distributed with a completed package.
The commands above use fresh filenames alongside the distributed results.
The regenerated file can be compared entry by entry with the canonical file;
do not overwrite that canonical file to force a comparison to pass.

Optional separate elementary checks are:

    python -B verify_supplement.py --case baselines --receipt baselines_O0_replay.json
    python -B verify_supplement.py --case witness --receipt witness_O0_replay.json
    python -B verify_supplement.py --case LL --seconds 60 --receipt LL_O0_replay.json

Every triple invocation already recomputes the baseline scalar guards and
the entire8385-cell-pair LL credit; the separate LL command is not a hidden
prerequisite. Run each of the four local obligations:

    python -B verify_supplement.py --case LLL --seconds 60 --nodes 100000 --receipt triple_LLL_O0_replay.json
    python -B verify_supplement.py --case SLL_i --seconds 60 --nodes 100000 --receipt triple_SLL_i_O0_replay.json
    python -B verify_supplement.py --case LSL_i --seconds 60 --nodes 100000 --receipt triple_LSL_i_O0_replay.json
    python -B verify_supplement.py --case SLL_e --seconds 60 --nodes 100000 --receipt triple_SLL_e_O0_replay.json

For actual optimized-mode replays, repeat with `-OO` and new output names.
These supplementary limits are cooperative, not hard wall-clock promises;
they never allow a remaining leaf to count as proved. A complete returning
cover is required. Optional `--detailed` saves every exact Taylor matrix,
gradient bound and cached point enclosure. Default compact receipts instead
record their exact canonical digests and counts, explicitly stating that
these details were generated and checked but not saved in that receipt.
The internal cover and its acceptance checks are identical in both modes.

After the gate and all four local cases actually complete, bind their new
source-generated receipts and assemble the rational regional bounds:

    python -B assemble_supplement.py --gate scalar_gates_O0_replay.json --triples triple_LLL_O0_replay.json triple_SLL_i_O0_replay.json triple_LSL_i_O0_replay.json triple_SLL_e_O0_replay.json --receipt regions_O0_replay.json

This last command checks receipt/source/data identity and exact algebra. It
does not independently validate arbitrary supplied cover logs. The separate
reconstruction algorithms establish the cover premises. The conclusion is
the all-long region and all twelve one-short regions, so a strict
counterexample to the proposed full floor must have at least two short
gaps. No complete twelve-dimensional floor or stronger global zero count
is inferred. In particular, the exact SLL upper witness rejects an earlier
overlarge local credit; it is not a counterexample to the full energy.

## Replay comparison and trust

The distributed completed evidence comprises the ordinary cosine cover,
ordinary and optimized two-mode covers, ordinary and optimized exact count
checks, one complete six-mode table generation, both modes of the scalar
gates, all four triples in both modes, and both regional assemblies. There
are also direct ordinary baseline and rejected-credit witness checks.
No optimized cosine replay is claimed or needed as an additional premise.
Repeating the same accepted cover algorithm is a useful software check,
not a second mathematical proof method.

The local identity/comparison check is:

    python -B check_release.py

It binds the selected receipts to the current sources, checks their complete
statuses and exact normal/optimized agreement after deleting only the listed
execution fields. It is not an independent numerical cover checker. The
publication source hashes are in MANIFEST.sha256. The main scalar receipts
are counts_final_O0/OO.json; the two-mode ordinary receipt is
two_mode_O0_run02.json. The remaining names are the non-replay versions of
the example names above. Existing output files are intentionally protected.

Compare mathematical fields of O0 and OO runs after excluding only the
declared execution metadata (optimization, elapsed time, interpreter version
text, and resource affinity details when genuinely platform-dependent).
Do not discard source hashes, exact configurations, table digests, or cover
counts to force agreement. Matching receipts are not a second proof method.
The scalar check and local covers serve different proof obligations.

`PROVENANCE.md` and `LICENSE-THIRD-PARTY` identify the original method and
publication changes. Generated receipts bind the package sources actually
used. Any refactoring changes those source hashes and requires a new run;
historical run counts and timings must never be attributed to an unexecuted
new source. The paper supplies the finite transfer and analytic limiting
arguments. This software neither computes zeta zeros nor proves RH.
