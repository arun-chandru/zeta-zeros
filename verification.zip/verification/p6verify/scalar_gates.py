"""Exact bootstrap and necessary one-dimensional gates for the six-mode row.

No historical receipt, private proof note, or external evaluator is loaded.
The calculation proves only necessary coordinate sets for a hypothetical
strict thirteen-point sublevel, never the complete twelve-gap inequality.

For the normalized density, 71/100 <= f <= 311/275 on [-1/2,1/2].
The derivative formula k'(x)=-4*pi*integral_0^(1/2) s*f(s)*sin(2*pi*x*s)
shows k is decreasing through 27/25: up to 1 the integrand is positive;
from 1 to 27/25 the positive integral on [1/8,3/8] is at least 71/3200,
while the entire possible negative tail is at most 311/14850. Their
difference is positive. This justifies the finite scalar bootstrap below.

Integration by parts bounds |k(x)| <= C/(pi*x) and
|k'(x)| <= C/x+C/(pi*x*x), where
C=12/11+sum|u_j|+2*sum j|u_j|. The differentiated Fourier integral also
gives |k'| <= pi*311/550. These are whole-cell bounds, not asymptotics.
"""

from collections import deque
from fractions import Fraction as Q
import time

from . import six_mode_exact as s

EPSILON = Q(31,5000)
P_ENDPOINT = Q(811,4800000)
P_INTERIOR = Q(6359,24000000)
PRESSURES = (P_ENDPOINT,P_INTERIOR)
FULL_PRESSURES = (P_ENDPOINT,)+(P_INTERIOR,)*10+(P_ENDPOINT,)
TOTAL = Q(239,80000)
DELTA,TAU = Q(231,250),Q(209,200)
RESIDUAL = Q(49249,16000000)
SHORT_UPPER = (Q(317,250),Q(633,500))
LONG_LOWER = Q(5,3)
MIN_WIDTH = Q(1,16384)
MAX_EVALUATIONS = 2500
WALL_CAP_SECONDS = 120
C = Q(12,11)+sum(abs(u) for u in s.U)+2*sum(j*abs(u) for j,u in enumerate(s.U,1))
GLOBAL_L = s.PI.hi*Q(311,550)


def kernel_at_cut(q):
    """Guard the same integrated Fourier formula on [5/6,27/25].

    This is needed for the initial cut 5/6, below the separately guarded
    domain of six_mode_exact.kernel_extended. No call widens that API.
    """
    s.require(Q(5,6) <= q <= Q(27,25),'Bootstrap point in proved domain')
    sine,cosine = s.sincos_pi(q)
    t = s.rounded(s.PI*q)
    denominator = 1-2*t*t
    s.require(denominator.hi < 0,'Strictly negative cosine denominator')
    value = s.rounded((cosine-2*(s.R0-Q(1,2))*t*sine)/denominator)
    for j,u in enumerate(s.U,1):
        if q == j:
            basis = s.I(Q(1,2))
        else:
            s.require(q*q != j*j,'No unhandled shifted-sinc resonance')
            basis = s.rounded((-1)**j*q*sine/(s.PI*(q*q-j*j)))
        value = s.rounded(value+u*basis)
    return value


def scalar_cuts():
    """Reprove delta=.924 and tau=1.045 from exact point inequalities.

    Each strict sublevel initially has gaps >5/6. If all gaps exceed d
    and one is <=d', monotonicity gives F >= k(d')^2/6+d*TOTAL.
    The tau test proves k(g)^2/6+p*g >= tau*p for every g>=d.
    Thereafter the refined cut is
    F >= k(d')^2/6+tau*TOTAL-max(p)*(tau-d).
    Only the successful, explicitly justified cuts are needed.
    """
    s.require(s.U == [Q(n,4000) for n in (37,-69,-1,8,-11,2)],'Fixed six-mode profile')
    s.require(sum(FULL_PRESSURES) == TOTAL and min(FULL_PRESSURES) > 0,'Positive pressure vector')
    amplitude = sum(abs(u) for u in s.U)
    s.require(amplitude == Q(4,125) and amplitude <= Q(1,25),'Profile amplitude bound')
    s.require(Q(3,4)-amplitude >= Q(71,100)
              and Q(12,11)+amplitude <= Q(311,275),'Elementary density bounds')
    sine_margin = Q(71,3200)-Q(311,14850)
    s.require(sine_margin > 0,'Positive monotonicity integral margin')
    s.require(RESIDUAL == EPSILON-TAU*TOTAL,'Exact residual scalar budget')
    s.require(C == Q(27751,22000) and s.PI.lo > 3,'Whole-half-line envelope constants')

    delta = Q(5,6)
    initial = kernel_at_cut(delta)
    initial_floor = s.rounded(initial*initial/6)
    s.require(initial.lo > 0 and initial_floor.lo > EPSILON,'Initial small-gap exclusion')
    records = []
    for next_delta in (Q(9,10),Q(91,100),Q(183,200),Q(917,1000),Q(459,500)):
        s.require(delta < next_delta <= 1,'Increasing initial bootstrap cuts')
        kval = kernel_at_cut(next_delta)
        floor = s.rounded(kval*kval/6+delta*TOTAL)
        s.require(kval.lo > 0 and floor.lo > EPSILON,'Strict initial bootstrap step')
        records.append(dict(phase='minimum_gap_bootstrap',old_delta=str(delta),
                            new_delta=str(next_delta),kernel=s.outer(kval),
                            conditional_floor=s.outer(floor)))
        delta = next_delta

    kval = kernel_at_cut(TAU)
    tau_margin = s.rounded(kval*kval/6-max(PRESSURES)*(TAU-delta))
    s.require(delta < TAU <= Q(27,25) and kval.lo > 0 and tau_margin.lo >= 0,
              'Nearest-term baseline on the entire conditional domain')
    records.append(dict(phase='nearest_term_baseline',delta=str(delta),tau=str(TAU),
                        kernel=s.outer(kval),required_margin=s.outer(tau_margin)))

    for next_delta in (Q(23,25),Q(461,500),Q(231,250)):
        s.require(delta < next_delta <= TAU,'Increasing refined bootstrap cuts')
        kval = kernel_at_cut(next_delta)
        floor = s.rounded(kval*kval/6+TAU*TOTAL-max(PRESSURES)*(TAU-delta))
        s.require(kval.lo > 0 and floor.lo > EPSILON,'Strict refined bootstrap step')
        records.append(dict(phase='nearest_baseline_refined_gap',old_delta=str(delta),
                            new_delta=str(next_delta),tau=str(TAU),
                            conditional_floor=s.outer(floor)))
        delta = next_delta
    s.require(delta == DELTA,'Final proved minimum-gap restriction')
    caps = [TAU+RESIDUAL/p for p in PRESSURES]
    s.require(caps == [Q(3124439,162200),Q(16103731,1271800)],'Exact individual caps')
    return dict(verified=True,target=str(EPSILON),delta=str(DELTA),tau=str(TAU),
                residual_budget=str(RESIDUAL),pressure_total=str(TOTAL),
                monotonicity_endpoint='27/25',sine_integral_derivative_margin=str(sine_margin),
                initial_cut='5/6',initial_kernel=s.outer(initial),initial_floor=s.outer(initial_floor),
                nearest_term_baseline_total=str(TAU*TOTAL),
                individual_gap_upper_bounds=[str(x) for x in caps],
                span_upper_bound=str(12*TAU+RESIDUAL/min(PRESSURES)),scalar_steps=records)


def pair(a,b):
    return [str(a),str(b)]


def merge_intervals(intervals):
    merged = []
    for a,b in sorted(intervals):
        if merged and a == merged[-1][1]:
            merged[-1][1] = b
        else:
            if merged:
                s.require(merged[-1][1] < a,'Disjoint merged intervals')
            merged.append([a,b])
    return merged


def calculate(seconds=WALL_CAP_SECONDS,max_evaluations=MAX_EVALUATIONS):
    """Cover both closed scalar domains, retaining every uncertain cell.

    The necessary inequality is W_p(g)=k(g)^2/6+p*(g-tau)<RESIDUAL.
    A discarded closed cell must have its rigorous W lower bound at least
    RESIDUAL. Strict-pass and unresolved-boundary cells are retained.
    A resource stop retains all remaining cells and cannot return verified.
    """
    s.require(type(seconds) is int and 1 <= seconds <= WALL_CAP_SECONDS,'Bounded scalar wall allowance')
    s.require(type(max_evaluations) is int and 1 <= max_evaluations <= MAX_EVALUATIONS,
              'Bounded exact midpoint allowance')
    start,cpu_start = time.monotonic(),time.process_time()
    bootstrap = scalar_cuts()
    caps = [TAU+RESIDUAL/p for p in PRESSURES]
    pending = deque((j,DELTA,cap) for j,cap in enumerate(caps))
    leaves,cache = [[],[]],{}
    visited = forced_unknown = 0
    budget_exhausted = False
    while pending:
        j,a,b = pending.popleft()
        s.require(DELTA <= a < b <= caps[j],'Cell inside exact initial domain')
        visited += 1
        p = PRESSURES[j]
        if time.monotonic()-start >= seconds or len(cache) >= max_evaluations:
            budget_exhausted = True
            forced_unknown += 1
            leaves[j].append((a,b,'unresolved_budget',dict(method='retained_without_discard')))
            continue
        envelope = min(Q(1),C/(s.PI.lo*a))
        wlo,whi = p*(a-TAU),envelope*envelope/6+p*(b-TAU)
        details = dict(method='integrated_profile_envelope',W_interval=s.outer(s.I(wlo,whi)))
        if wlo >= RESIDUAL:
            status = 'excluded'
        elif whi < RESIDUAL:
            status = 'strict_gate_pass'
        else:
            center,radius = (a+b)/2,(b-a)/2
            if center not in cache:
                cache[center] = s.kernel_extended(center)
            kval = cache[center]
            local_l = min(GLOBAL_L,C/a+C/(s.PI.lo*a*a))
            lo,hi = kval.lo-local_l*radius,kval.hi+local_l*radius
            abs_lo = max(Q(0),lo,-hi)
            abs_hi = min(envelope,max(abs(lo),abs(hi)))
            s.require(abs_lo <= abs_hi,'Consistent exact whole-cell kernel bounds')
            wlo,whi = abs_lo*abs_lo/6+p*(a-TAU),abs_hi*abs_hi/6+p*(b-TAU)
            details = dict(method='midpoint_and_global_derivative',center=str(center),
                           kernel_at_center=s.outer(kval),derivative_bound=str(local_l),
                           W_interval=s.outer(s.I(wlo,whi)))
            if wlo >= RESIDUAL:
                status = 'excluded'
            elif whi < RESIDUAL:
                status = 'strict_gate_pass'
            elif b-a <= MIN_WIDTH:
                status = 'unresolved_boundary'
            else:
                pending.append((j,a,center))
                pending.append((j,center,b))
                continue
        if status == 'excluded':
            s.require(wlo >= RESIDUAL,'Every discarded closed cell proves W>=B')
        elif status == 'strict_gate_pass':
            s.require(whi < RESIDUAL,'Every strict-pass cell proves W<B throughout')
        leaves[j].append((a,b,status,details))

    outputs = []
    localization_checks = []
    for j,data in enumerate(leaves):
        data.sort(key=lambda row: row[0])
        s.require(data and data[0][0] == DELTA and data[-1][1] == caps[j],'Both initial endpoints covered')
        for left,right in zip(data,data[1:]):
            s.require(left[1] == right[0],'Exact no-hole no-interior-overlap partition')
        s.require(sum((b-a for a,b,_,_ in data),Q(0)) == caps[j]-DELTA,'Exact total partition length')
        allowed = merge_intervals([(a,b) for a,b,status,_ in data if status != 'excluded'])
        excluded = merge_intervals([(a,b) for a,b,status,_ in data if status == 'excluded'])
        localized = (len(allowed) == 2 and DELTA <= allowed[0][0]
                     and allowed[0][1] <= SHORT_UPPER[j]
                     and LONG_LOWER <= allowed[1][0] and allowed[1][1] <= caps[j])
        localization_checks.append(localized)
        outputs.append(dict(pressure_kind='endpoint' if j == 0 else 'interior',
            pressure=str(PRESSURES[j]),initial_closed_domain=pair(DELTA,caps[j]),
            allowed_closed_superset=[pair(a,b) for a,b in allowed],
            allowed_outer_decimal_intervals=[s.outer(s.I(a,b)) for a,b in allowed],
            excluded_closed_intervals=[pair(a,b) for a,b in excluded],
            excluded_total_length=str(sum((b-a for a,b in excluded),Q(0))),
            allowed_total_length=str(sum((b-a for a,b in allowed),Q(0))),
            required_short_upper=str(SHORT_UPPER[j]),required_long_lower=str(LONG_LOWER),
            two_component_localization_verified=localized,
            leaf_status_counts={status:sum(row[2] == status for row in data)
                                for status in sorted(set(row[2] for row in data))},
            leaves=[dict(closed_interval=pair(a,b),status=status,**details)
                    for a,b,status,details in data]))
    verified = not budget_exhausted and all(localization_checks)
    return dict(publication_schema='p6.scalar-gates.v1',
        status='PASS_NECESSARY_SCALAR_GATES' if verified else 'INCOMPLETE_NECESSARY_SCALAR_GATES',
        verified=verified,
        scope='Necessary closed coordinate supersets only; not a full thirteen-point inequality.',
        target=str(EPSILON),delta=str(DELTA),tau=str(TAU),B=str(RESIDUAL),
        pressures=[str(p) for p in PRESSURES],full_pressure_vector=[str(p) for p in FULL_PRESSURES],
        pressure_total=str(TOTAL),profile=[[j,str(u)] for j,u in enumerate(s.U,1)],
        bootstrap=bootstrap,kernel_envelope_numerator=str(C),
        global_kernel_derivative_bound=str(GLOBAL_L),minimum_leaf_width=str(MIN_WIDTH),
        evaluation_cap=max_evaluations,wall_cap_seconds=seconds,budget_exhausted=budget_exhausted,
        budget_retained_cells=forced_unknown,visited_cells=visited,
        distinct_midpoint_evaluations=len(cache),partitions=outputs,
        wall_seconds=time.monotonic()-start,cpu_seconds=time.process_time()-cpu_start)
