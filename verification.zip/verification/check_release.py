"""Check packaged receipt identity and declared replay agreement.

This checks consistency of source-generated evidence; it does not independently
reconstruct interval enclosures or certify arbitrary supplied proof logs.
"""
import copy
import hashlib
import json
from pathlib import Path
from p6verify.exact import require

BASE = Path(__file__).resolve().parent


def read(name, directory='receipts'):
    path = BASE/directory/name
    return json.loads(path.read_text(encoding='utf-8'))


def source_map(mapping):
    require(isinstance(mapping,dict) and mapping,'Nonempty source identity map')
    for name,pin in mapping.items():
        path = (BASE/name).resolve()
        require(path.is_relative_to(BASE) and path.is_file(),'Existing package-local source')
        require(hashlib.sha256(path.read_bytes()).hexdigest().lower() == pin.lower(),
                'Current source identity: '+name)


def equal_except(a,b,paths):
    a,b = copy.deepcopy(a),copy.deepcopy(b)
    for path in paths:
        for data in (a,b):
            for part in path[:-1]:
                data = data[part]
            require(path[-1] in data,'Declared execution field exists')
            del data[path[-1]]
    require(a == b,'All other fields must agree exactly')


def main():
    counts = [read('counts_final_'+mode+'.json') for mode in ('O0','OO')]
    for mode,row in zip((0,2),counts):
        require(row['status'] == 'PASS_EXACT_SCALARS' and row['optimization'] == mode,
                'Actually completed scalar check')
        source_map(row['source_sha256'])
    equal_except(*counts,[('optimization',)])
    ordinary = read('two_mode_O0_run02.json')
    optimized = read('two_mode_OO.json')
    cosine = read('cosine_O0.json')
    for row,mode in ((ordinary,0),(optimized,2),(cosine,0)):
        require(row['status'] == 'PASS_COMPLETE_LOCAL_ROW' and row['report']['verified']
                and row['optimization'] == mode,'Actual complete main local row')
        source_map(row['source_sha256'])
        report = row['report']
        require(report['nodes'] == report['splits']+report['pruned']
                and report['initial_boxes']+report['splits'] == report['pruned'],
                'Complete main covering forest accounting')
    equal_except(ordinary,optimized,[('optimization',),('report','elapsed_seconds')])
    table = read('six_mode_tables.json','data')
    require(table['status'] == 'PASS_COMPLETE_SCALAR_TABLES','Actual complete table generator')
    source_map(table['source_sha256'])
    gates = [read('scalar_gates_'+mode+'.json') for mode in ('O0','OO')]
    for row,mode in zip(gates,(0,2)):
        require(row['verified'] and row['status'] == 'PASS_NECESSARY_SCALAR_GATES'
                and row['optimization'] == mode and not row['budget_exhausted'],
                'Actually completed necessary gates')
        source_map(row['source_hashes'])
    equal_except(*gates,[('optimization',),('wall_seconds',),('cpu_seconds',)])
    for case in ('LLL','SLL_i','LSL_i','SLL_e'):
        rows = [read('triple_'+case+'_'+mode+'.json') for mode in ('O0','OO')]
        for row,mode in zip(rows,(0,2)):
            require(row['verified'] and row['status'] == 'EXACT_REBALANCED_TRIPLE_TAYLOR_PASS'
                    and row['optimization'] == mode and row['case'] == case
                    and row['pending_count'] == row['terminal_count'] == 0,
                    'Actually complete supplementary triple')
            source_map(row['package_sources'])
        equal_except(*rows,[('optimization',),('runtime_seconds',),('cpu_seconds',),
                            ('wall_seconds_including_setup',)])
    for mode in ('O0','OO'):
        row = read('regions_'+mode+'.json')
        require(row['status'] == 'PASS_REGIONAL_ASSEMBLY'
                and row['full_thirteen_point_floor_proved'] is False,
                'Correctly scoped regional conclusion')
        for name,pin in row['input_receipt_sha256'].items():
            require(hashlib.sha256((BASE/'receipts'/name).read_bytes()).hexdigest() == pin,
                    'Regional input receipt binding')
        require(hashlib.sha256((BASE/'assemble_supplement.py').read_bytes()).hexdigest()
                == row['source_sha256'],'Regional assembler identity')
    require(read('regions_O0.json')['regional_lower_bounds'] ==
            read('regions_OO.json')['regional_lower_bounds'],'Exact regional agreement')
    for name,status in (('baselines_O0.json','PASS_BASELINE_SCALARS'),
                        ('witness_O0.json','PASS_EXACT_UPPER_WITNESS')):
        row = read(name)
        require(row['verified'] and row['status'] == status,'Completed direct scalar obligation')
        source_map(row['package_sources'])
    print('PASS_RELEASE_CONSISTENCY')
    print('Scope: source/receipt identity, complete-status checks and exact replay comparison.')
    print('Cosine row: one ordinary execution; no optimized replay is claimed.')
    print('This check is not an independent numerical cover or proof-log verifier.')


if __name__ == '__main__':
    main()
