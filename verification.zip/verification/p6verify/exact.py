"""Independent rational interval arithmetic; standard library only.

No historical checker, saved decimal enclosure, or numerical library is
imported. Alternating series and integer-square-root brackets supply all
transcendental constants. Guards remain active under Python -OO.
"""
from fractions import Fraction as Q
from math import factorial, isqrt


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


class I:
    def __init__(self, lo, hi=None):
        self.lo = Q(lo)
        self.hi = self.lo if hi is None else Q(hi)
        require(self.lo <= self.hi, 'Ordered interval')

    def __add__(self, other):
        other = box(other)
        return I(self.lo+other.lo, self.hi+other.hi)

    __radd__ = __add__

    def __neg__(self):
        return I(-self.hi, -self.lo)

    def __sub__(self, other):
        return self+-box(other)

    def __rsub__(self, other):
        return box(other)+-self

    def __mul__(self, other):
        other = box(other)
        products = [a*b for a in (self.lo,self.hi) for b in (other.lo,other.hi)]
        return I(min(products),max(products))

    __rmul__ = __mul__

    def __truediv__(self, other):
        other = box(other)
        require(not other.lo <= 0 <= other.hi, 'Nonzero interval divisor')
        return self*I(1/other.hi,1/other.lo)

    def __rtruediv__(self, other):
        return box(other)/self


def box(value):
    return value if isinstance(value,I) else I(value)


def rounded(value, digits=50):
    value = box(value)
    scale = 10**digits
    return I(Q(value.lo.numerator*scale//value.lo.denominator,scale),
             Q(-((-value.hi.numerator*scale)//value.hi.denominator),scale))


def square(value):
    value = box(value)
    return I(0 if value.lo <= 0 <= value.hi else min(value.lo**2,value.hi**2),
             max(value.lo**2,value.hi**2))


def sqrt_interval(value, digits=60):
    value = box(value)
    require(value.lo >= 0, 'Nonnegative square root')
    scale = 10**digits
    def floor_root(x):
        return isqrt(x.numerator*scale*scale//x.denominator)
    lo,hi = Q(floor_root(value.lo),scale),Q(floor_root(value.hi)+1,scale)
    require(lo*lo <= value.lo and hi*hi > value.hi, 'Exact root brackets')
    return I(lo,hi)


def outer(value, digits=24):
    value = box(value)
    scale = 10**digits
    lo = value.lo.numerator*scale//value.lo.denominator
    hi = -((-value.hi.numerator*scale)//value.hi.denominator)
    def decimal(n):
        sign = '-' if n < 0 else ''
        n = abs(n)
        return sign+str(n//scale)+'.'+str(n%scale).zfill(digits)
    return [decimal(lo),decimal(hi)]


def atan_inverse(n):
    require(isinstance(n,int) and n >= 2, 'Alternating arctangent domain')
    # Fifty terms end negative; the next positive term bounds the error.
    partial = sum((Q((-1)**j,(2*j+1)*n**(2*j+1)) for j in range(50)),Q(0))
    return I(partial,partial+Q(1,101*n**101))


def pi_interval():
    return rounded(16*atan_inverse(5)-4*atan_inverse(239))


def cosine_energy():
    # C=cos(z), S=sin(z)/z, z^2=1/2. Forty-one terms end positive;
    # adding the next negative term brackets the alternating tail.
    def series(offset):
        total = sum((Q((-1)**j,2**j*factorial(2*j+offset))
                     for j in range(41)),Q(0))
        return rounded(I(total-Q(1,2**41*factorial(82+offset)),total))
    C,S = series(0),series(1)
    require(C.lo > 0 and S.lo > 0, 'Positive trigonometric denominators')
    R = rounded(Q(1,2)+C/S)
    A = rounded(1/(2*S*S)+C/(2*S))
    return R,A,rounded(R-A)
