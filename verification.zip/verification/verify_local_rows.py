"""Rebuild and completely cover one adopted seven-point row.

No historical source, table, or receipt is imported. Failure, interruption,
node exhaustion, or an unresolved atomic cell never writes a PASS receipt.
Use run_bounded.py for a separately enforced hard wall-clock limit.
"""
import argparse
import ctypes
from dataclasses import asdict
import hashlib
import json
import os
from pathlib import Path
import sys

sys.dont_write_bytecode = True
for variable in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):
    os.environ[variable] = '1'

from p6verify.exact import require
from p6verify.rows import ROWS

BASE = Path(__file__).resolve().parent


def one_cpu():
    if os.name == 'nt':
        win = ctypes.WinDLL('kernel32',use_last_error=True)
        win.GetCurrentProcess.restype = ctypes.c_void_p
        handle = win.GetCurrentProcess()
        mask,system = ctypes.c_size_t(),ctypes.c_size_t()
        win.GetProcessAffinityMask.argtypes = [ctypes.c_void_p,ctypes.POINTER(ctypes.c_size_t),ctypes.POINTER(ctypes.c_size_t)]
        win.SetProcessAffinityMask.argtypes = [ctypes.c_void_p,ctypes.c_size_t]
        win.SetPriorityClass.argtypes = [ctypes.c_void_p,ctypes.c_uint32]
        require(bool(win.GetProcessAffinityMask(handle,ctypes.byref(mask),ctypes.byref(system)))
                and mask.value > 0,'Read available CPU mask')
        selected = mask.value & -mask.value
        require(bool(win.SetProcessAffinityMask(handle,selected)),'One CPU affinity')
        require(bool(win.SetPriorityClass(handle,0x4000)),'Below-normal priority')
        return dict(enforced=True,selected_affinity_mask=selected,priority='below_normal')
    if hasattr(os,'sched_getaffinity'):
        selected = min(os.sched_getaffinity(0))
        os.sched_setaffinity(0,{selected})
        os.nice(5)
        return dict(enforced=True,selected_cpu=selected,priority='nice_plus_5')
    raise RuntimeError('No implemented one-CPU enforcement on this platform')


def source_hashes():
    names = ('__init__.py','exact.py','rows.py','kernel.py','rounding.py',
             'report.py','profiles.py','cover.py')
    paths = [Path(__file__),*(BASE/'p6verify'/name for name in names)]
    return {path.relative_to(BASE).as_posix():hashlib.sha256(path.read_bytes()).hexdigest()
            for path in paths}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--row',choices=tuple(ROWS),required=True)
    parser.add_argument('--nodes',type=int,required=True)
    parser.add_argument('--receipt',required=True,help='New JSON basename in receipts/')
    args = parser.parse_args()
    require(1 <= args.nodes <= 2000000,'Node limit in reviewed finite range')
    destination = (BASE/'receipts'/args.receipt).resolve()
    require(destination.parent == BASE/'receipts' and destination.suffix == '.json'
            and not destination.exists(),'New local JSON receipt')
    sources = source_hashes()
    affinity = one_cpu()
    import flint
    from p6verify.cover import verify_window
    from p6verify.profiles import Profile
    row = ROWS[args.row]
    metadata = row.metadata()
    # The cosine path deliberately keeps the original cosine callbacks.
    # The perturbed path uses one immutable object for all three callbacks.
    callbacks = Profile(row.profile) if row.profile else None
    print('START COMPLETE SEVEN-POINT COVER '+json.dumps(metadata,sort_keys=True),flush=True)
    report = verify_window(row.points,row.epsilon,row.pressure,row.grid,args.nodes,
                           progress_every=5000,callbacks=callbacks)
    require(report.verified is True,'Whole cover completed')
    require(report.nodes == report.pruned+report.splits
            and report.initial_boxes+report.splits == report.pruned,'Complete tree accounting')
    details = report.details
    require(report.grid == row.grid and report.precision_bits == row.precision_bits
            and details['points'] == row.points and details['epsilon'] == str(row.epsilon)
            and details['pressure'] == str(row.pressure)
            and details['cutoff_cells'] == metadata['cutoff_cells'],'Exact row identity')
    require(sum(details[name] for name in ('pressure_pruned','interval_pruned','tangent_pruned'))
            == report.pruned,'Complete leaf classification')
    require(source_hashes() == sources,'Sources unchanged during execution')
    result = dict(schema='p6.local-row.v1',status='PASS_COMPLETE_LOCAL_ROW',
        optimization=sys.flags.optimize,row=metadata,report=asdict(report),
        node_limit=args.nodes,resources=affinity,source_sha256=sources,
        python_version=sys.version,python_flint_version=getattr(flint,'__version__','unavailable'),
        scope='Completed whole-orthant raw seven-point inequality only; finite transfer and zero-count deductions are separate.')
    with destination.open('x',encoding='utf-8') as stream:
        json.dump(result,stream,indent=2,sort_keys=True)
        stream.write('\n')
    print('PASS '+str(destination),flush=True)


if __name__ == '__main__':
    main()
