"""Run one exact supplementary local obligation, never the full twelve-gap floor.

All mathematical imports are package-local. Four successful local triple
executions and the independent scalar gate are needed for the final regional
reduction; this command does not turn one local PASS into a global one.
"""
import argparse
from fractions import Fraction as Q
import hashlib
import json
from pathlib import Path
import sys
import time
from p6verify.exact import I,require,rounded,square,outer
from p6verify import supplement as e
from p6verify import six_mode_exact as point
from verify_local_rows import one_cpu

BASE = Path(__file__).resolve().parent


def original_credit_witness():
    gaps = [Q(n,10**8) for n in (105423000,200939700,202645700)]
    require(Q(459,500) <= gaps[0] <= Q(633,500)
            and all(Q(5,3) <= x < e.LONG for x in gaps[1:]),
            'Witness label and worst-pressure branch')
    result = I(sum((e.PI*(x-(e.SHORT if j == 0 else e.LONG)) for j,x in enumerate(gaps)),Q(0)))
    for h,weight in ((1,Q(1,6)),(2,Q(2,11)),(3,Q(1,5))):
        for i in range(4-h):
            value = point.kernel(sum(gaps[i:i+h],Q(0)))
            result = rounded(result+weight*square(value))
    old_target = Q(365723,2400000000)
    require(result.hi < old_target,'Old standalone interior SLL target refuted')
    return dict(status='PASS_EXACT_UPPER_WITNESS',verified=True,gaps=[str(x) for x in gaps],
                cost=outer(result),rejected_target=str(old_target),
                scope='One exact SLL upper witness, not a global thirteen-point counterexample.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--case',choices=('baselines','LL','LLL','SLL_i','LSL_i','SLL_e','witness'),required=True)
    parser.add_argument('--seconds',type=int,default=10)
    parser.add_argument('--nodes',type=int,default=100000)
    parser.add_argument('--receipt',required=True)
    parser.add_argument('--detailed',action='store_true',help='Save every exact Taylor log and cached point enclosure')
    args = parser.parse_args()
    require(1 <= args.seconds <= 120 and 1 <= args.nodes <= 100000,'Finite cooperative envelope')
    destination = (BASE/'receipts'/args.receipt).resolve()
    require(destination.parent == BASE/'receipts' and destination.suffix == '.json'
            and not destination.exists(),'New supplementary receipt')
    source_paths = [Path(__file__),BASE/'verify_local_rows.py',*(BASE/'p6verify'/name for name in
                   ('__init__.py','exact.py','rows.py','six_mode_exact.py','supplement.py','triple_cover.py'))]
    source_snapshot = {path.relative_to(BASE).as_posix():hashlib.sha256(path.read_bytes()).hexdigest()
                       for path in source_paths}
    one_cpu()
    started = time.monotonic()
    if args.case == 'baselines':
        result = dict(**e.baseline_checks(),verified=True)
    elif args.case == 'witness':
        result = original_credit_witness()
    elif args.case == 'LL':
        e.load_table(started+args.seconds)
        result = dict(**e.LAST_LL,verified=True)
    else:
        from p6verify.triple_cover import calculate
        result = calculate(e,args.case,args.seconds,args.nodes)
    result['publication_schema'] = 'p6.supplement-local.v1'
    result['optimization'] = sys.flags.optimize
    result['entrypoint_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    require(source_snapshot == {path.relative_to(BASE).as_posix():hashlib.sha256(path.read_bytes()).hexdigest()
                                for path in source_paths},'Supplement sources unchanged during execution')
    result['package_sources'] = source_snapshot
    result['wall_seconds_including_setup'] = time.monotonic()-started
    result['detail_mode'] = 'detailed' if args.detailed else 'compact'
    if not args.detailed:
        omitted = {}
        for key in ('accepted_taylor_cells','point_cache_q'):
            if key in result:
                rows = result.pop(key)
                digest = hashlib.sha256(json.dumps(rows,sort_keys=True,separators=(',',':')).encode('ascii')).hexdigest()
                omitted[key] = dict(count=len(rows),sha256=digest,
                    encoding='ASCII JSON sort_keys=True separators=(comma,colon)',
                    disposition='Validated/generated during execution, not saved in this compact receipt')
        result['omitted_detail'] = omitted
    with destination.open('x',encoding='utf-8') as stream:
        json.dump(result,stream,indent=2,sort_keys=True)
        stream.write('\n')
    print(json.dumps({key:value for key,value in result.items() if key not in
        ('accepted_taylor_cells','point_cache_q','pending_boxes','unresolved_atomic_cells')},indent=2,sort_keys=True))
    return 0 if result['verified'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
