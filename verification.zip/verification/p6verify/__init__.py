"""Self-contained numerical verifiers accompanying the P6 manuscript.

Importing this package does not run a cover or require python-flint.
"""
