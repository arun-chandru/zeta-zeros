"""Recompute adopted constants independently. No local cover is run here."""
from fractions import Fraction as Q
import argparse
import hashlib
import json
from pathlib import Path
import sys

from p6verify.exact import I,cosine_energy,outer,pi_interval,require,rounded,sqrt_interval
from p6verify.rows import COSINE,TWO_MODE

BASE = Path(__file__).resolve().parent


def calculate():
    pi = pi_interval()
    R0,A0,B0 = cosine_energy()
    require(Q(3) < pi.lo < pi.hi < Q(22,7), 'Pi enclosure sanity')
    require(Q(1327,1000) < R0.lo < R0.hi < Q(1328,1000), 'Cosine energy sanity')
    cost,A1 = I(0),A0
    for j,u in TWO_MODE.profile:
        cost = rounded(cost+(Q(1,2)-1/(4*pi*pi*j*j))*u*u)
        A1 = rounded(A1+2*(-1)**(j+1)*u/(2*pi*pi*j*j-1)+u*u/2)
    R1 = rounded(R0+cost)
    B1 = rounded(R1-A1)
    a,d = TWO_MODE.epsilon,6*TWO_MODE.pressure
    aC,dC = COSINE.epsilon,6*COSINE.pressure
    b7 = Q(2,49)/sum((Q(1,j) for j in range(1,7)),Q(0))
    s = rounded(sqrt_interval(2*(1-a)))
    gamma,t,Z = rounded(4+2*s),rounded(1+s),rounded(3-a+2*s)
    T,beta = rounded(R1+d),rounded(R1+d-1-a)
    E = rounded(beta/Z)
    # Exact coefficients in Q[s]/(s^2-2(1-a)), not interval tests at zero.
    gamma_coefficients = (Q(4),Q(2))
    square_relation = 2*(1-a)
    gc,gs = gamma_coefficients
    z_coefficients = ((gc*gc+gs*gs*square_relation)/8,2*gc*gs/8)
    require(z_coefficients == (3-a,Q(2)), 'Exact Gamma squared over eight')
    require((gc-1-z_coefficients[0]-a,gs-z_coefficients[1]) == (0,0),
            'Symbolic Gamma-1-Z-a identity')
    guards = {
        'density_positive_cosine': R0-Q(1,2),
        'density_positive_two_mode': R0-Q(1,2)-sum(abs(u) for j,u in TWO_MODE.profile),
        'cosine_norm_one_cap': I(b7-aC),
        'two_mode_not_norm_one': I(a-b7),
        'two_mode_threshold_two_cap': I(4*b7-a),
        'two_mode_union_cap': b7*t*t-a,
        'a_positive': I(a),'half_minus_a': I(Q(1,2)-a),
        'beta_positive': beta,'six_minus_T': 6-T,
        'three_minus_T_minus_a': 3-T-a,'one_minus_two_a': I(1-2*a),
        'distinct_two_denominator': 8-2*T-a,'Gamma_minus_T': gamma-T,
        'higher_cutoff_cost': 4*(gamma-T)+beta-gamma*gamma/4,
        'E_positive': E,'half_minus_E': Q(1,2)-E,
        'A0_minus_B0': A0-B0,'B0_positive': B0,
        'A1_minus_B1': A1-B1,'B1_positive': B1,
        'union_t_above_two': t-2,
    }
    require(b7 == Q(40,2401) and a/b7 == Q(16807,16000), 'Exact uniform-row cap')
    for name,value in guards.items():
        require(value.lo > 0, 'Strict guard: '+name)
    C = rounded((2-R0-dC)/(1-aC))
    values = dict(simple_critical_over_N=C,distinct_over_N=rounded((1+C)/2),
                  union_over_N=rounded(1-2*E),mass_two_over_N=rounded((3-T)/(2-a)),
                  distinct_two_over_Ndistinct=rounded(1-beta/(8-2*T-a)))
    headlines = dict(zip(values,('0.673058325315610967','0.836529162657805483',
                                '0.888554068993217696','0.837368508521536857',
                                '0.939197203148497742')))
    for name,value in values.items():
        require(Q(headlines[name]) < value.lo <= value.hi < 1, 'Strict headline margin: '+name)
    baseline_union = rounded(1-2*(R0-1)/(3+2*sqrt_interval(2)))
    baseline_mass = rounded((3-R0)/2)
    baseline_distinct = rounded(1-(R0-1)/(2*(4-R0)))
    gains = dict(union_over_named_formula=rounded(values['union_over_N']-baseline_union),
                 mass_two_over_named_formula=rounded(values['mass_two_over_N']-baseline_mass),
                 distinct_two_over_named_formula=rounded(values['distinct_two_over_Ndistinct']-baseline_distinct))
    gain_headlines = dict(zip(gains,('0.000934060819863356',
                                   '0.001118156681831034',
                                   '0.000469272388685036')))
    require(all(value.lo > Q(gain_headlines[name]) for name,value in gains.items()),
            'Strict printed named-formula improvement margins')
    family = {}
    for r in (3,4,5,10):
        family[str(r)] = dict(mass=outer(1-Q(r+1,r-1)*E),
                              distinct=outer(1-E/(r-1-r*E)))
    sources = [Path(__file__),BASE/'p6verify'/'__init__.py',
               BASE/'p6verify'/'exact.py',BASE/'p6verify'/'rows.py']
    return dict(schema='p6.exact-counts.v1',status='PASS_EXACT_SCALARS',
        optimization=sys.flags.optimize,
        scope='Exact consequences conditional on the separately proved two local rows and analytic transfer; no cover, zero computation, or outside verifier is run.',
        rows=[row.metadata() for row in (COSINE,TWO_MODE)],
        constants={name:outer(value) for name,value in dict(pi=pi,R0=R0,A0=A0,B0=B0,
            R1=R1,A1=A1,B1=B1,profile_cost=cost,Gamma=gamma,t_union=t,Z=Z,T=T,beta=beta,E=E).items()},
        exact_cap=str(b7),symbolic_zero_coefficient=True,
        guards={name:outer(value) for name,value in guards.items()},
        counts={name:outer(value) for name,value in values.items()},headlines=headlines,
        headline_margins={name:outer(value-Q(headlines[name])) for name,value in values.items()},
        named_baseline_formulas=dict(union=outer(baseline_union),mass_two=outer(baseline_mass),
                                    distinct_two=outer(baseline_distinct)),
        named_gains={name:outer(value) for name,value in gains.items()},
        named_gain_headlines=gain_headlines,
        named_gain_margins={name:outer(value-Q(gain_headlines[name])) for name,value in gains.items()},
        fixed_cutoff_families=dict(scope='Every fixed integer r>=3; symbolic denominator guard 0<E<1/2.',
            mass_formula='1-(r+1)*E/(r-1)',distinct_formula='1-E/(r-1-r*E)',examples=family),
        source_sha256={path.relative_to(BASE).as_posix():hashlib.sha256(path.read_bytes()).hexdigest()
                       for path in sources})


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--receipt',help='Optional new JSON file in receipts/')
    args = parser.parse_args()
    destination = (BASE/'receipts'/args.receipt).resolve() if args.receipt else None
    if destination is not None:
        require(destination.parent == BASE/'receipts' and not destination.exists(), 'New local receipt required')
    result = calculate()
    encoded = json.dumps(result,indent=2,sort_keys=True)+'\n'
    if destination is not None:
        with destination.open('x',encoding='utf-8') as stream:
            stream.write(encoded)
    print(encoded,end='')
