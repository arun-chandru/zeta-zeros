"""The two adopted seven-point inputs, as exact immutable specifications."""
from dataclasses import dataclass
from fractions import Fraction as Q


@dataclass(frozen=True)
class Row:
    name: str
    epsilon: Q
    pressure: Q
    profile: tuple
    points: int = 7
    grid: int = 4000
    precision_bits: int = 128

    def metadata(self):
        cap = self.epsilon*self.grid/self.pressure
        cutoff = -(-cap.numerator//cap.denominator)
        return dict(name=self.name,points=self.points,grid=self.grid,
                    precision_bits=self.precision_bits,epsilon=str(self.epsilon),
                    pressure=str(self.pressure),span_debit=str(6*self.pressure),
                    profile=[[j,str(u)] for j,u in self.profile],
                    cutoff_cells=cutoff,table_cell_count=cutoff+self.points+1)


COSINE = Row('cosine',Q(19,5000),Q(1,3000),())
TWO_MODE = Row('two_mode',Q(7,400),Q(1,500),
               ((1,Q(13,500)),(2,Q(-7,500))))
ROWS = {row.name:row for row in (COSINE,TWO_MODE)}
